/*
测试matlab和c混合编程中的生成矩阵和返回值
输入：任意矩阵
输出：在这个矩阵后添加一个维度

XueZhimeng, 2020.10
*/

#include "mex.h"
#include "math.h"

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] ) {
    /* Check for proper number of arguments. */
    if(nrhs!=1) {
        mexErrMsgTxt("1 inputs are required.");
    } else if(nlhs<1) {
        mexErrMsgTxt("One outputs are required");
    }

    double *Dxx = (double *)mxGetPr(prhs[0]);
    
    /* Loop variable */
    int i;

    /* Size of input */
    const mwSize *idims;
    int nsubs=0;

    /* Number of pixels */
    int npixels = 1;

    /*  Get the number of dimensions */
    nsubs = mxGetNumberOfDimensions(prhs[0]);
    /* Get the sizes of the inputs */
    idims = mxGetDimensions(prhs[0]);
    for (i=0; i<nsubs; i++) { npixels=npixels*idims[i]; }

    // 构造返回值
    mwSize odims[nsubs+1];
    for (i=0; i<nsubs; i++) { odims[i]=idims[i]; }
    odims[nsubs] = 2;
    
    plhs[0] = mxCreateNumericArray(nsubs+1, odims, mxDOUBLE_CLASS, mxREAL);
    double *pMatirx = mxGetPr(plhs[0]);

    // 赋值
    for(i=0; i<npixels; i++) { pMatirx[i*2] = Dxx[i]; pMatirx[i*2+1] = Dxx[i]+1; }
}